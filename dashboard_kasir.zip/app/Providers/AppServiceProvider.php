<?php

// app/Providers/BladeServiceProvider.php

namespace App\Providers;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class BladeServiceProvider extends ServiceProvider
{
    /**
     * Register the Blade components.
     *
     * @return void
     */
    public function boot()
    {
    }

    public function register()
    {
        //
    }
}
