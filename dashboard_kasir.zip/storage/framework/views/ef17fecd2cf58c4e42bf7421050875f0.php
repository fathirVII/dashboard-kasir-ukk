<?php if (isset($component)) { $__componentOriginal7ae6b45c011e855a5545a671a7f3568e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Dashboard Stok Produk
     <?php $__env->endSlot(); ?>

    <?php if(session('success')): ?>
        <div class=" bg-[#262537] px-6 py-4 mt-4 rounded-2xl shadow-md">
            <div class="bg-green-400 text-black p-4 rounded-md mb-4">
                <?php echo e(session('success')); ?>

            </div>
        </div>
    <?php endif; ?>
    <?php if(session('delete')): ?>
        <div class=" bg-[#262537] px-6 py-4 mt-4 rounded-2xl shadow-md">
            <div class="bg-red-400 text-white p-4 rounded-md mb-4">
                <?php echo e(session('delete')); ?>

            </div>
        </div>
    <?php endif; ?>

    <div class=" bg-[#262537] px-6 py-4 mt-4 rounded-2xl shadow-md">

        <div class="flex justify-between mb-5">
            <h1 class="text-lg font-bold uppercase mb-4">Tabel Produk</h1>
            <a href="<?php echo e(route('produk.create')); ?>"
                class="px-3 py-1 mb-2 bg-green-500 text-gray-200 rounded-md hover:bg-green-600 transition">Tambah Data
                Produk</a>
        </div>


        <div class="grid grid-cols-1 gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 xl:gap-x-8">

            <?php $__currentLoopData = $dataProduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('produk.edit', $item->id_produk)); ?>" class="group">
                    <img src="https://cdn.thewirecutter.com/wp-content/media/2024/07/laptopstopicpage-2048px-3685-2x1-1.jpg?width=2048&amp;quality=75&amp;crop=2:1&amp;auto=webp"
                        alt="Tall slender porcelain bottle with natural clay textured body and cork stopper."
                        class="aspect-square w-full rounded-lg bg-gray-200 object-cover group-hover:opacity-75 xl:aspect-7/8">

                    <p class="mt-1 text-lg font-medium text-gray-200">Nama : <?php echo e($item->nama_produk); ?></p>
                    <h3 class="mt-1 text-sm text-gray-200">Kategori : <?php echo e($item->kategori); ?></h3>
                    <h3 class="mt-1 text-sm text-gray-200">Harga : <?php echo e($item->harga); ?></h3>
                    <h3 class="mt-1 text-sm text-gray-200">Stok : <?php echo e($item->stok); ?></h3>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $attributes = $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $component = $__componentOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php /**PATH A:\TUGAS UJIKOM\dashboard_kasir\resources\views/produk/dashboard-produk.blade.php ENDPATH**/ ?>