<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dark UI</title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-background text-light font-roboto min-h-screen">

    <!-- Sidebar -->
  <?php echo $__env->make('layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <nav class="bg-surface p-4 shadow-md">
    <div class="container mx-auto flex justify-between items-center">
      <h1 class="text-xl font-bold text-primary">MyApp</h1>
    </div>
  </nav>

  <main class="container mx-auto px-4 py-6">
    <?php echo e($slot); ?> 
  </main>

</body>
</html>
<?php /**PATH A:\TUGAS UJIKOM\dashboard_kasir\resources\views/layouts/app.blade.php ENDPATH**/ ?>