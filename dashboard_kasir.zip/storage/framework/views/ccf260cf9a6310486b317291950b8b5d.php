<?php if (isset($component)) { $__componentOriginal7ae6b45c011e855a5545a671a7f3568e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Dashboard Detail Penjualan
     <?php $__env->endSlot(); ?>
    <div class=" bg-[#262537] px-6 py-4 mt-4 rounded-2xl shadow-md">
        <div class="">
            <h1 class="text-lg font-bold uppercase mb-4">Tabel Penjualan</h1>
            <table
                class="min-w-full text-[clamp(0.9rem,0.9vw,1rem)] border-collapse rounded-xl overflow-hidden shadow-lg">
                <thead class="bg-[#4363D0] text-white">
                    <tr>
                        <th class="px-4 py-3 text-left">No</th>
                        <th class="px-4 py-3 text-left">Nama</th>
                        <th class="px-4 py-3 text-left">Tanggal Penjualan</th>
                        <th class="px-4 py-3 text-left">Total Pembayaran</th>
                        <th class="px-4 py-3 text-left">Action</th>
                    </tr>
                </thead>
                <tfoot class="bg-[#262537] text-white">
                    <tr>
                        <th class="px-4 py-2 text-left">No</th>
                        <th class="px-4 py-2 text-left">Nama</th>
                        <th class="px-4 py-2 text-left">Tanggal Penjualan</th>
                        <th class="px-4 py-2 text-left">Total Pembayaran</th>
                        <th class="px-4 py-2 text-left">Action</th>
                    </tr>
                </tfoot>
                <tbody class="bg-[#35374E] text-[#cbd1ff]">
                    <?php $__currentLoopData = $dataPenjualan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $totalPembayaran = 0;
                        ?>
                        <tr class="hover:bg-[#54577b] transition duration-300 border-b">
                            <td class="px-4 py-3"><?php echo e($i++); ?></td>
                            <td class="px-4 py-3"><?php echo e($item->pembeli->nama ?? 'Tidak Diketahui'); ?></td>
                            <td class="px-4 py-3">
                                <?php echo e(\Carbon\Carbon::parse($item->tanggal_penjualan)->translatedFormat('d F')); ?>

                            </td>
                            <?php
                                foreach ($item->detail as $data) {
                                    $totalPembayaran += $data->sub_total;
                                }
                            ?>
                            <td class="px-4 py-3">Rp.<?php echo e(number_format($totalPembayaran, 0, ',', '.')); ?></td>
                            <td class="px-4 py-3 space-x-2 flex">
                                <a href="<?php echo e(route('detail-penjualan.index', ['id_penjualan' => $item->id_penjualan])); ?>"
                                    class="px-3 py-1 bg-blue-500 text-white rounded-md hover:bg-blue-700 transition">Detail</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $attributes = $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $component = $__componentOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php /**PATH A:\TUGAS UJIKOM\dashboard_kasir\resources\views/penjualan/dashboard-penjualan.blade.php ENDPATH**/ ?>