<?php if (isset($component)) { $__componentOriginal7ae6b45c011e855a5545a671a7f3568e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Dashboard Detail Penjualan
     <?php $__env->endSlot(); ?>
    <div class=" bg-[#262537] px-6 py-4 mt-4 rounded-2xl shadow-md">
        <div class=" font-sans">

            <div class="text-center mb-4">
                <h1 class="text-xl font-bold">Detail Penjualan</h1>
                <p class="text-sm text-gray-2">
                   ID Penjualan <?php echo e($penjualan->id_penjualan); ?></p>
                <p class="text-sm text-gray-2">
                    <?php echo e(\Carbon\Carbon::parse($penjualan->tanggal_penjualan)->format('d M Y, H:i')); ?></p>
            </div>

            <div class="mb-4">
                <p><span class="font-semibold">ID Penjualan:</span> <?php echo e($penjualan->id_penjualan); ?></p>
                <p><span class="font-semibold">Pelanggan:</span>
                    <?php echo e($penjualan->pembeli->nama ?? 'Umum'); ?></p>
                <p><span class="font-semibold">Alamat:</span>
                    <?php echo e($penjualan->pembeli->alamat); ?></p>
            </div>

            <div class="border-t border-b py-2 my-2">
                <div class="flex justify-between font-semibold text-gray-200">
                    <span class="w-1/4 truncate">Produk</span>
                    <span class="w-1/4 truncate">Id Produk</span>
                    <span class="w-1/4 text-center">Qty x Harga</span>
                    <span class="w-1/4 text-right">Subtotal</span>
                </div>
                <?php
                    $totalPembayaran = 0;
                ?>

                <?php $__currentLoopData = $penjualan->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex justify-between text-sm text-gray-200 mt-1">
                        <span class="w-1/4 truncate"><?php echo e($detail->produk->nama); ?></span>
                        <span class="w-1/4 truncate"><?php echo e($detail->produk->id_produk); ?></span>
                        <span class="w-1/4 text-center"><?php echo e($detail->jumlah_barang); ?> x
                            <?php echo e(number_format($detail->produk->harga)); ?></span>
                        <span class="w-1/4 text-right"><?php echo e(number_format($detail->sub_total)); ?></span>
                    </div>
                    <?php
                        $totalPembayaran += $detail->sub_total;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="flex justify-between text-lg font-semibold mt-4">
                <span>Total</span>
                <span>Rp <?php echo e(number_format($totalPembayaran)); ?></span>
            </div>

 


        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $attributes = $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $component = $__componentOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php /**PATH A:\TUGAS UJIKOM\dashboard_kasir\resources\views/penjualan/detail-penjualan.blade.php ENDPATH**/ ?>