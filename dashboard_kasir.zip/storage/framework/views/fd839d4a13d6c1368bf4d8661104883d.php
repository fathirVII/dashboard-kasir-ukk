<?php if (isset($component)) { $__componentOriginal7ae6b45c011e855a5545a671a7f3568e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Dashboard Detail Pelanggan
     <?php $__env->endSlot(); ?>
    <div class=" bg-[#262537] px-6 py-4 mt-4 rounded-2xl shadow-md">
        <?php if(session('success')): ?>
            <div class="bg-green-400 text-black p-4 rounded-md mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('delete')): ?>
            <div class="bg-red-400 text-white p-4 rounded-md mb-4">
                <?php echo e(session('delete')); ?>

            </div>
        <?php endif; ?>
        <div class="flex justify-between">
            <h1 class="text-lg font-bold uppercase mb-4">Tabel Pelanggan</h1>
            <a href="<?php echo e(route('pelanggan.create')); ?>"
                class="px-3 py-1 mb-2 bg-green-500 text-gray-200 rounded-md hover:bg-green-600 transition">Tambah Data
                Pelanggan</a>
        </div>
        <table class="min-w-full text-[clamp(0.9rem,0.9vw,1rem)] border-collapse rounded-xl overflow-hidden shadow-lg">
            <thead class="bg-[#4363D0] text-white">
                <tr>
                    <th class="px-4 py-3 text-left">No</th>
                    <th class="px-4 py-3 text-left">Nama</th>
                    <th class="px-4 py-3 text-left max-lg:hidden">Alamat</th>
                    <th class="px-4 py-3 text-left">No Telepon</th>
                    <th class="px-4 py-3 text-left">Jumlah Pembelian</th>
                    <th class="px-4 py-3 text-left">Action</th>
                </tr>
            </thead>
            <tfoot class="bg-[#262537] text-white">
                <tr>
                    <th class="px-4 py-3 text-left">No</th>
                    <th class="px-4 py-3 text-left">Nama</th>
                    <th class="px-4 py-3 text-left max-lg:hidden">Alamat</th>
                    <th class="px-4 py-3 text-left">No Telepon</th>
                    <th class="px-4 py-3 text-left">Jumlah Pembelian</th>
                    <th class="px-4 py-3 text-left">Action</th>
                </tr>
            </tfoot>
            <tbody class="bg-[#35374E] text-[#cbd1ff]">
                <?php $__currentLoopData = $dataPelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-[#54577b] transition duration-300 border-b">
                        <td class="px-4 py-3"><?php echo e($i++); ?></td>
                        <td class="px-4 py-3"><?php echo e($item->nama ?? 'Tidak Diketahui'); ?></td>
                        <td class="px-4 py-3 max-lg:hidden"><?php echo e($item->alamat ?? 'Tidak Diketahui'); ?></td>
                        <td class="px-4 py-3">
                            <?php echo e($item->no_telepon); ?>

                        </td>
                        <td class="px-4 py-3">
                            <?php echo e($dataPenjualan->where('id_pelanggan', $item->id_pelanggan)->count()); ?></td>
                        <td class="px-4 py-3 space-x-2 flex">
                            <a href="<?php echo e(route('pelanggan.edit', $item->id_pelanggan)); ?>"
                                class="px-3 py-1 bg-yellow-500 text-black rounded-md hover:bg-yellow-600 transition">Edit</a>
                            <form action="<?php echo e(route('pelanggan.destroy', $item->id_pelanggan)); ?>" method="POST"
                                style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                    class="px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600 transition">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $attributes = $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $component = $__componentOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php /**PATH A:\TUGAS UJIKOM\dashboard_kasir\resources\views/pelanggan/dashboard-pelanggan.blade.php ENDPATH**/ ?>