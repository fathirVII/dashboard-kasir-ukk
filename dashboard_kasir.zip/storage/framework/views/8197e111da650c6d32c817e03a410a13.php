<div class="w-64 h-screen bg-surface text-light shadow-md">
    <div class="p-5">
        <h2 class="text-2xl font-bold text-primary">MyApp</h2>
        <p class="text-sm">Welcome to the Admin Panel</p>
    </div>
    <nav class="mt-6">
        <ul>
            <li>
                <a href="<?php echo e(route('dashboard')); ?>" class="block px-5 py-3 text-sm hover:bg-primary hover:text-light transition-colors rounded-md">
                    Dashboard
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('pelanggan.index')); ?>" class="block px-5 py-3 text-sm hover:bg-primary hover:text-light transition-colors rounded-md">
                    Pelanggan
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('produk.index')); ?>" class="block px-5 py-3 text-sm hover:bg-primary hover:text-light transition-colors rounded-md">
                    Produk
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('settings')); ?>" class="block px-5 py-3 text-sm hover:bg-primary hover:text-light transition-colors rounded-md">
                    Pengaturan
                </a>
            </li>
        </ul>
    </nav>
</div>
<?php /**PATH A:\TUGAS UJIKOM\dashboard_kasir\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>