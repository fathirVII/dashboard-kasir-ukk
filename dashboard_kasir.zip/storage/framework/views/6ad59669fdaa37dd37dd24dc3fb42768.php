<?php if (isset($component)) { $__componentOriginal7ae6b45c011e855a5545a671a7f3568e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Dashboard <?php $__env->endSlot(); ?>

    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-6">
        <div class="bg-[#4363D0] text-white p-6 rounded-2xl shadow-xl">
            <h2 class="text-md font-semibold">Total Keuntungan</h2>
            <p class="text-2xl font-bold mt-2">Rp <?php echo e(number_format($totalKeuntungan, 0, ',', '.')); ?></p>
        </div>

        <div class="bg-[#4CAF50] text-white p-6 rounded-2xl shadow-xl">
            <h2 class="text-md font-semibold">Jumlah Pelanggan</h2>
            <p class="text-2xl font-bold mt-2"><?php echo e($jumlahPelanggan); ?></p>
        </div>

        <div class="bg-[#9C27B0] text-white p-6 rounded-2xl shadow-xl">
            <h2 class="text-md font-semibold">Jumlah Produk</h2>
            <p class="text-2xl font-bold mt-2"><?php echo e($jumlahProduk); ?></p>
        </div>

        <div class="bg-[#FFC107] text-black p-6 rounded-2xl shadow-xl">
            <h2 class="text-md font-semibold">Total Penjualan</h2>
            <p class="text-2xl font-bold mt-2"><?php echo e($jumlahPenjualan); ?></p>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $attributes = $__attributesOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__attributesOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e)): ?>
<?php $component = $__componentOriginal7ae6b45c011e855a5545a671a7f3568e; ?>
<?php unset($__componentOriginal7ae6b45c011e855a5545a671a7f3568e); ?>
<?php endif; ?>
<?php /**PATH A:\TUGAS UJIKOM\dashboard_kasir\resources\views/dashboard.blade.php ENDPATH**/ ?>